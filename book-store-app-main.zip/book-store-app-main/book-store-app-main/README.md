# Book Store App

## Pre-Requisites

1. Install packages


## Usage:

cd #Book Store App

```

Open `# Book Store App
s` and `main.tf` files under the Modules directory your editor. In `# NATOURS-BE-APP-MAIN
` file update below variables according to your envirnoment.
```



```

In `main.tf` file update below block of backend to choose between local or remote backend
```
terraform {
  backend "s3" {
    bucket = "Book Store App
    key    = "stg/terraform.tfstate"
    region = "ap-southeast-2"
  }
  # backend "local" {
  #   path = "# Book Store App
"
  # }
}
#AWS-LAMBDA 
source                  = "./Modules#/ Book Store App
"
  function_name           = var.function_name
  handler                 = var.handler
  runtime                 = var.runtime
  file_name               = file("${path.module}/./Modules/# Book Store App
  source_code_hash        = base64sha256(file("${path.module}/./Modules/# Book Store App
/hello.py"))
  end_point               = var.function_name
  accountid               = var.accountid
  type                    = "HTTP_PROXY"
  integration_http_method = "POST"
  region                  = var.region
  provisioned_concurrent_executions = var.provisioned_concurrent_executions 
```

Then change the directory tp `AWS-Lambda` and run below commands to create the resources in AWS
```
terraform init
terraform plan
terraform apply
```

Cleanup: To remove run below commands
```
terraform destroy
```
